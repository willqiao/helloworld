from pprint import pprint
from math import floor
from copy import deepcopy

class Solution:
    def solveSudoku(self, board):
        """
        :type board: List[List[str]]
        :rtype: void Do not return anything, modify board in-place instead.
        """
        fullset = set(["1","2","3","4","5","6","7","8","9"])        
        blocks = [[set() for i in range(3)] for i in range(3)]
        columns = [set() for i in range(9)]
        rows = [set() for i in range(9)]
        
        mymap = {}
        for rindex in range(len(board)):
            for cindex in range(len(board[rindex])):
                if board[rindex][cindex] != ".":
                    blocks[floor(rindex/3)][floor(cindex/3)].add(board[rindex][cindex])
                    columns[cindex].add(board[rindex][cindex])
                    rows[rindex].add(board[rindex][cindex])
                else :
                    if mymap.get((rindex,cindex)) == None:
                        mymap[(rindex,cindex)] = set()
                
        
        done = self.reduceMymap(mymap, rows, columns, blocks, board)
        
        if done == False:
            
            
            for key in mymap:
                done = False
                for value in mymap[key]:
                    copymap = deepcopy(mymap)
                    copyrows = deepcopy(rows)
                    copycolumns = deepcopy(columns)
                    copyblocks = deepcopy(blocks)
                    
                    print(key)
                    del copymap[key]
                    
                    board[key[0]][key[1]] = value
                    copyrows[key[0]].add(value)
                    copycolumns[key[1]].add(value)
                    copyblocks[floor(key[0]/3)][floor(key[1]/3)].add(value)
                    
                    done = self.reduceMymap(copymap, copyrows, copycolumns, copyblocks, board)
                    if done == True:
                        break
                
                if done == True:
                    print(board)
                    break
        
#         if done == False:
#             copymap = deepcopy(mymap)

#             resultPossibilities = []
#             print()
#             pprint(copymap)
#             rowi = 0
#             columni = 0
#             while rowi =:
#                 for value in copymap[key]:
#                     resultPossibilities.append(object)
                    
        
        
    def reduceMymap(self, mymap, rows,columns,blocks,board):
        fullset = set(["1","2","3","4","5","6","7","8","9"])
        while len(mymap) > 0:
            #build mymap
            for key in mymap:
                r = key[0]
                c = key[1]    
                diff = fullset - (rows[r]|columns[c]|blocks[floor(r/3)][floor(c/3)])    
                mymap[key]=diff
            
            pprint(mymap)
            
            #put single one back to array
            tobedelete = []
            for key in mymap:
                if len(mymap.get(key)) == 1:
                    value = mymap.get(key).pop()
                    board[key[0]][key[1]] = value
                    rows[key[0]].add(value)
                    columns[key[1]].add(value)
                    blocks[floor(key[0]/3)][floor(key[1]/3)].add(value)
                    tobedelete.append(key)
            
            if len(tobedelete) != 0 :
                for key in tobedelete:
                    del mymap[key]        

            else:
                return False

        return True
                    





















board = [
  ["5","3",".",".","7",".",".",".","."],
  ["6",".",".","1","9","5",".",".","."],
  [".","9","8",".",".",".",".","6","."],
  ["8",".",".",".","6",".",".",".","3"],
  ["4",".",".","8",".","3",".",".","1"],
  ["7",".",".",".","2",".",".",".","6"],
  [".","6",".",".",".",".","2","8","."],
  [".",".",".","4","1","9",".",".","5"],
  [".",".",".",".","8",".",".","7","9"]
]

board = [['.', '.', '9', '7', '4', '8', '.', '.', '.'],
 ['7', '.', '.', '.', '.', '.', '.', '.', '.'],
 ['.', '2', '.', '1', '.', '9', '.', '.', '.'],
 ['.', '.', '7', '.', '.', '.', '2', '4', '.'],
 ['.', '6', '4', '.', '1', '.', '5', '9', '.'],
 ['.', '9', '8', '.', '.', '.', '3', '.', '.'],
 ['.', '.', '.', '8', '.', '3', '.', '2', '.'],
 ['.', '.', '.', '.', '.', '.', '.', '.', '6'],
 ['.', '.', '.', '2', '7', '5', '9', '.', '.']]


# board[0][5] = var
Solution().solveSudoku(board)
pprint(board)
# pprint(rows)
# pprint(columns)
# pprint(blocks)
# pprint(mymap)











hello = {(0, 0): {'5', '3', '6'},
 (0, 1): {'1', '5', '3'},
 (0, 6): {'1', '6'},
 (0, 7): {'1', '5', '3'},
 (0, 8): {'5', '3', '2'},
 (1, 1): {'1', '8', '3', '5', '4'},
 (1, 2): {'1', '5', '3'},
 (1, 4): {'5', '3'},
 (1, 6): {'1', '8', '4'},
 (1, 7): {'1', '8', '5', '3'},
 (1, 8): {'5', '4', '3', '9'},
 (2, 0): {'8', '3', '6', '5', '4'},
 (2, 2): {'5', '3', '6'},
 (2, 4): {'5', '3'},
 (2, 6): {'8', '7', '6', '4'},
 (2, 7): {'5', '8', '7', '3'},
 (2, 8): {'5', '4', '3'},
 (3, 0): {'5', '3'},
 (3, 1): {'5', '3'},
 (6, 0): {'5', '4', '9'},
 (6, 1): {'1', '7', '5', '4'},
 (6, 2): {'1', '5'},
 (6, 6): {'1', '7', '4'},
 (6, 8): {'5', '4'},
 (7, 0): {'5', '8', '3'},
 (7, 1): {'5', '8', '7', '3'},
 (7, 2): {'5', '3', '2'},
 (7, 6): {'8', '7'},
 (7, 7): {'5', '8', '7', '3'},
 (8, 0): {'8', '4', '3', '6'},
 (8, 1): {'1', '8', '4', '3'},
 (8, 2): {'1', '3', '6'},
 (8, 7): {'1', '8', '3'},
 (8, 8): {'4', '3'}}
















